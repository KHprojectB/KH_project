package com.myhome.web.login.model;

public class RegiRes {
	String message;

    public RegiRes (String message) {
        this.message = message;
    }
    
    public void setMessage(String message) {
		this.message = message;
	}
	public String getMessage() {
		return message;
	}
}
