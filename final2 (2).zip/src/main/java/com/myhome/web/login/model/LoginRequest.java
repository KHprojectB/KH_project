package com.myhome.web.login.model;

public class LoginRequest {
	
	private String mbId;
	private String mbPw;
	
	public String getMbId() {
		return mbId;
	}
	
	public String getMbPw() {
		return mbPw;
	}
	

}
