package com.myhome.web.login.service;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;

import com.myhome.web.login.model.MemberDAO;
import com.myhome.web.login.model.MemberDTO;
import com.myhome.web.login.model.RegiRes;

@Service
public class RegisterService {
	@Autowired
	private MemberDAO memberDao;

	public ResponseEntity<RegiRes> save(@RequestBody @Valid MemberDTO memberDto){
		System.out.println("memberDto=" + memberDto);

		memberDao.insertUser(memberDto);

		RegiRes r = new RegiRes("회원가입에 성공하셨습니다.");
		return ResponseEntity.ok(r);
	}

}
